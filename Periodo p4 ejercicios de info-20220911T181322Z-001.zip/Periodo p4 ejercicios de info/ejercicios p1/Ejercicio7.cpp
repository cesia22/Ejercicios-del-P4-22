#include<iostream>
using namespace std;

int main()
{
int numero;
cout<<"**Bienvenido al dectector de numeros negativos**"<<endl;
cout<<"**Porfavor Ingrese el numero**"<<endl;
cin>>numero;
if (numero<0)
{
cout<<"**El numero Ingresado es Negativo**"<<endl;
}else{
cout<<"**El numero Ingresado no es negativo**"<<endl;
}
	return 0;
}
