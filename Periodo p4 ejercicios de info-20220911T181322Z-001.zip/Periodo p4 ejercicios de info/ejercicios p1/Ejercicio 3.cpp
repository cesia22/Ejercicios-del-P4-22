#include <iostream>
using namespace std;

int main(){
	double nota;
	cout << "Por favor ingrese su nota:  ";
	cin >> nota;

	if (nota >= 6)
	cout << "felicidades esta aprobado" ;
	else if (nota < 6)
	cout << "necesita mejorar" ; 
}
	
	
