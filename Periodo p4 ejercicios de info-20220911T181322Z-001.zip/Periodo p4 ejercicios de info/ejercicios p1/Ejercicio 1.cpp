#include<iostream>

using namespace std;

int main () {
	
	int x, y, mayor, menor;
	printf("ingresa dos numeros ");
	scanf ("%d%d" ,&x, &y);
	mayor=x;
	if(y>mayor)
	mayor=y;
	printf("El numero mayor es %d ", mayor);
	
	menor=x;
	if(y<menor)
	menor=y;
	printf("El numero menor es %d ", menor);
	
}

