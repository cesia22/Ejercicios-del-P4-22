#include <iostream>
using namespace std;

int main(){
	int ventas;
	int bono;
	bool repeticion= true;
	
	
	cout <<"Ingrese la cantidad de ventas realizadas por el empleado."<<endl<< ">>>";
	cin >> ventas;
	
	if (ventas > 0 && ventas <= 0){
		bono=0.05;
 }else if (ventas <=100){
 	bono =0.10;
 }else if(ventas>0 && ventas <= 200){
 	bono = 0.15;
 } else {
 	cout << "la cantidad ingresada no es valida";
 	exit;
 }
 	
 	cout << "El empleado genero" << ventas << "ventas"<< endl << "El bono ganado es de:" <<(bono*100) <<"%";
 }

