#include <iostream>
using namespace std;

int main() {
	
	float numero,numero_mayor =0;
	
	for(int contador=0;contador <5;contador ++){
		cout <<"ingrese un numero:" << endl << ">>>";
		cin >> numero;
		
		if (numero > numero_mayor){
			numero_mayor = numero;
			
		}
	}
	cout <<"El numero mayor es:" <<endl<< numero_mayor;
}


