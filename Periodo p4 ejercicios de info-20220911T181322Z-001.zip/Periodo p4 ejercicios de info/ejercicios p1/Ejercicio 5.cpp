#include <iostream>
using namespace std;
int main(){
int i;
double promedio,suma=0,n;
for(i=1;i<=10;i++){
cout<<"Introduca las notas ";
cin>>n;
if(n>0 && n<=10){
suma=suma+n;
}else{
cout<<"Valores erroneos "<<endl;
i--;
}
}
promedio=suma/10;
cout<<"La suma de los valores es "<<suma<<endl;
cout<<"El promedio es "<<promedio;
}
