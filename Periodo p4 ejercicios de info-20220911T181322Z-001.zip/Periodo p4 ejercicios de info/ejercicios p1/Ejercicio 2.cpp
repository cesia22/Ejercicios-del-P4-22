#include<iostream>

using namespace std;

int main(){
	int hora;
	cout<<"Digite un numero entero que corresponda a una hora: ";
	cin>>hora;
	if(hora>=0 && hora<12){
		cout<<"Buenos dias";
		}
	else if(hora>=12 && hora<18){
		cout<<"Buenas tardes";
		}
	else if(hora>=18 && hora<24){
		cout<<"Buenas noches";
		}
	else{
		cout<<"Hora no valida";
		}

	
	
	
	return 0;
}
