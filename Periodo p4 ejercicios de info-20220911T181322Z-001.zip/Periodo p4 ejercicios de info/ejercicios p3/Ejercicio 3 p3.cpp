/*Escribir un programa, que pida por teclado el resultado obtenido al lanzar un dado 
de 6 caras.Y muestre por pantalla el numero de la cara opuesta al resultado obtenido*/
#include <iostream>
using namespace std;
int main(){
	int numero;
	cout<<"Digite el numero de la cara del dado obtenido"<<endl;
	cin>>numero;
	switch (numero){
		case 1: cout<<"El numero de la cara contraria es:6";break;
		case 2: cout<<"El numero de la cara contraria es:5";break;
		case 3: cout<<"El numero de la cara contraria es:4";break;
		case 4: cout<<"El numero de la cara contraria es:3";break;
		case 5: cout<<"El numero de la cara contraria es:2";break;
		case 6: cout<<"El numero de la cara contraria es:1";break;
	default:cout<<"El numero ingresado no se encuentra en un dado";break;
	}
	return 0;
}
