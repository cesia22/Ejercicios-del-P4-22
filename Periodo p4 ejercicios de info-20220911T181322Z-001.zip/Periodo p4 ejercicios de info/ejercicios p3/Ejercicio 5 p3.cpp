#include <iostream> 
using namespace std; 

int main () 
{ 
 float salario, aumento;
 char contrato;
cout<<"Indique su tipo de contrato (a,b,c o d)"<<endl;
cout<<"a) De 0 a $500"<<endl;
cout<<"b) Mas de $500 a $1000"<<endl;
cout<<"c) Mas de $100 a $1500"<<endl;
cout<<"d) Mas de $1500"<<endl;
cin>>contrato;
cout<<"Ingrese su salario actual"<<endl;
cin>>salario;

 switch (contrato)
 {
  case 'a': case 'A': 
  aumento = salario + (salario * 0.2);
  cout<<"Su nuevo salario sera: "<<aumento<<endl;
  break;
  case 'b': case 'B': 
  aumento = salario + (salario * 0.1);
  cout<<"Su nuevo salario sera: "<<aumento<<endl;
  break;
  case 'c': case 'C': 
  aumento = salario + (salario * 0.05);
  cout<<"Su nuevo salario sera: "<<aumento<<endl;
  break;
  case 'd': case 'D': 
  aumento = salario + (salario * 0.03);
  cout<<"Su nuevo salario sera: "<<aumento<<endl;
  break;
  default:
  cout<<"Opcion no valida";
 }
 
return 0;
}
