#include <iostream>  
using namespace std;  

int main () {
	int x; 
	float pulgada, kilo, DISTANCIA, PESO;
	cout<< "Que desea convertir, distancia o peso "<<endl;
	cout<< "Escriba 1 para distancia "<<endl;
	cout<< "Escriba 2 para peso ";
	cin>> x;
	
	switch(x){
		
		case 1: 
		cout<<"Ingrese la distancia en centimetros"<<endl;
        cin>>DISTANCIA;
        pulgada = DISTANCIA / 2.54;
        cout<<"Las pulgadas son: "<<pulgada<<endl;
        
        break;
        
        case 2:  
        cout<<"Ingrese el peso en libras"<<endl;
        cin>>PESO;
        kilo = PESO * (1 / 2.21);
        cout<<"Las kilogramos son: "<<kilo<<endl;
        
        break;
        
        default:
        cout<<"Opcion no valida";
	}

}
