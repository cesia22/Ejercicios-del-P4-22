#include <iostream>
using namespace std; 

int main()
{
  int num1,num2,i;
  cout<< "ingresa el primer valor :"  <<endl;
  cin>> num1;
  cout<< "ingresar el ultimo valor: " <<endl;
  cin>> num2;
  cout<< endl;
  for(i=num1; i<=num2 ;i++)
  cout<< i << endl;
  return 0;
  
}
