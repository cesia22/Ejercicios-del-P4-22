#include<iostream>
using namespace std;

int main(){
	cout<<"************Bienvenido digita un numero del 1 al 12 para seleccionar su debido mes**********"<<endl;
	int mes;
	cin>>mes;
	if(mes ==1){
		cout<<"El mes que usted escogio es Enero\n";
	}
	if(mes==2){
		cout<<"El mes que usted escogio es Febrero";
	}
	if(mes==3){
		cout<<"El mes que usted escogio es Marzo\n";
	}
	if(mes==4){
		cout<<"El mes que usted escogio es Abril\n";
	}
	if(mes==5){
		cout<<"El mes que usted escogio es Mayo\n";
	}
	if(mes==6){
		cout<<"El mes que usted escogio es Junio\n";
	}
	if(mes==7){
		cout<<"El mes que usted escogio es Julio\n";
	}
	if(mes==8){
		cout<<"El mes que usted escogio es Agosto\n";
	}
	if(mes==9){
		cout<<"El mes que usted escogio es Septiembre\n";
	}
	if(mes==10){
		cout<<"El mes que usted escogio es Octubre\n";
	}
	if(mes==11){
		cout<<"El mes que usted escogio es Noviembre\n";
	}
	if(mes==12){
		cout<<"El mes que usted escogio es Diciembre\n";
	}
	if(mes<=0||mes>=13){
		cout<<"Lo siento el numero que ingreso no representa ningun mes\n";
	}
	
}
