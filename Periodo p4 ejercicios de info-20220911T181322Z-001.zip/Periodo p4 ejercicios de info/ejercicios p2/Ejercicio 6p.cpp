#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main ()
{
	float altura,base,respuesta;
	for (int contador=1;contador<4;contador++)	
	{
		printf("Introduzca la base\n");
		scanf("%f",&base);
		printf("Introduzca la altura\n");
		scanf("%f",&altura);
		printf("El resultado final del �rea es %.2f\n",(base*altura)/2);
	}
}
