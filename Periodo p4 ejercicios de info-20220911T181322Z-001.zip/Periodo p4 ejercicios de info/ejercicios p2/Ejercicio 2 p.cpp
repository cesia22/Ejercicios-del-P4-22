#include <iostream>
using namespace std;

int main(){
	
	int numeros [11];
	int suma=0;
	
	for(int i = 0; i<11; i++){
		cout <<"introduce un valor para la posicion "<<i<<":";
		cin>> numeros [i];
	}
	
	suma=0;
	for(int i=0; i<11; i++){
		suma= suma + numeros[i];
	}
	cout<<"la media es " << ((float)suma)/11;
	
}

