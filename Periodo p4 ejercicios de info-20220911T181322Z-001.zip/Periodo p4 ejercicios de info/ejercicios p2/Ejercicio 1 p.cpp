#include <iostream>
using namespace std;
 
float menor ( float n1, float n2 )
{
    if (n1<n2)
        return n1;
    else
        return n2;
}
 
int main()
{
    float numero1, numero2;
 
    cout << "Dime un n�mero: ";
    cin >> numero1;
    cout << "Dime otro: ";
    cin >> numero2;
    cout << "El menor es ";
    cout << menor(numero1, numero2) << endl;
 
    return 0;
}
