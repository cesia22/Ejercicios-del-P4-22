#include <iostream>
using namespace std;

int main(){
    
    int num, mayor, menor;
    for(int i=0; i<5; i++){
        printf ("ingrese la nota: ");
        scanf("%d", &num);
        if (i==0){
            mayor=num;
            menor=num;
    
        }
        else {
            if(num> mayor) mayor=num;
            if(num<menor) menor=num;
        }
    }
        printf("la nota mayor es %d ", mayor);
        printf (" la nota menor es %d ", menor);
    
}


